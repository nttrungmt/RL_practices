# CLaiR

This repository contains a solution to the LunarLanderContinuous-v2 OpenAI Gym Environment: CLaiR 

CLaiR is an open source project completed with resources from OpenAI in the Lunar Lander Continuous environment. The Lunar Lander uses a Proximal Policy Optimization Algorithm to learn a successful landing policy. The environment defines a solution as receiving an average score of 200 or more over 100 consecutive trials. CLaiR received an average score of 232 over 100 consecutive trials, solving the environment. A complete guide for how to install the LunarLander and LunarLanderContinuous enviornments can be found at the following link, https://medium.com/@brian.s.haney44/installing-spinningup-for-mac-os-x-9d5e24dc565a.

Copyright Martian Technologies 2019
